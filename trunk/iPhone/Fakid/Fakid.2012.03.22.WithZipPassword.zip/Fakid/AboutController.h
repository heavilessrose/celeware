

#import <UIKit/UIKit.h>

//
@interface AboutController : UITableViewController
{
	UIViewController *controller;
}
@property(nonatomic,retain) id specifier;
@property(nonatomic,retain) UIViewController *controller;
@property(nonatomic,retain) UIViewController *rootController;
@property(nonatomic,retain) UIViewController *parentController;
@end
